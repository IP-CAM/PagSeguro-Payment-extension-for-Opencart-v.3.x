<?php
//Heading
$_['heading_title'] = 'PagSeguro - Cartão de Crédito';

//Text
$_['text_pagseguro_cartao'] = '<img src="view/image/payment/pagseguro.png" />';