<?php
//Heading
$_['heading_title'] = 'PagSeguro - Boleto';

//Text
$_['text_pagseguro_boleto'] = '<img src="view/image/payment/pagseguro.png" />';