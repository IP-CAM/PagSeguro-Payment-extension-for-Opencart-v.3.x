<?php
// Heading Title
$_['heading_title'] = 'PagSeguro - Desconto';